package assignment1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.Test;

class TestClass1 {

Customer cust1;
	
	@Before
	public void setUp() {
		cust1 = new Customer("123", "Harris", "100");
		
	}

	@Test
	public void idTest() {
		//Customer cust1 = new Customer("123", "Harris", "100");
		System.out.println(cust1.getId());
		assertEquals("123", cust1.getId());
	}

}
