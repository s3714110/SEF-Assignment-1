package assignment1;

public class Employee {
	
	private String empId;
	private String empName;

	public Employee (String empId, String empName) {
		this.empId = empId;
		this.empName = empName;
	}
	public String getEmpId() {
		return empId;
	}
	
	public String getEmpName() {
		return empName;
	}


}
