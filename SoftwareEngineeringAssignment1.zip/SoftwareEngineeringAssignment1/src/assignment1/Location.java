package assignment1;

public class Location {

}
