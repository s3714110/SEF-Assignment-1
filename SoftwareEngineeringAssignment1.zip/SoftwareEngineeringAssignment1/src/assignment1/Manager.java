package assignment1;

public class Manager {
	
	private String managerName;
	private String managerID;
	private String managerStore;
	private int managerSalary; ///???? may not be needed.

	public String getManagerName() {
		return managerName;
	};
	
	
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	};
	
	public String getManagerID() {
		return managerID;
	};
	
	public void setManagerID(String managerID) {
		this.managerID = managerID;
	};
	
	public String getManagerStore() {
		return managerStore;
	};
	
	public void setManagerStore(String managerStore) {
		this.managerStore = managerStore;
	};
	
	public int getManagerSalary() {
		return managerSalary;
	};
	
	public void setManagerSalary(int managerSalary){
		this.managerSalary = managerSalary;
	};

	///Most of these may be included in another class:
	///getHighestRevenue(), reorderStock(), setPromotionalPrice(), setBulkSales(), generateSalesReport(), generateSupplyReport(), 
	
	///public String getHighestRevenue() {
		///Code goes here///
		///return highestRevinue; 
	///}
	
	///etc.
}
